import React, {useEffect, useState} from "react";
import './App.css';
import Axios from "axios";
import Card from "./components/cards/cards";


////criação das rotas 
//import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  const [values, setValues] = useState();
  const [listCard, setListCard] = useState([]);
  console.log(listCard);
  const handleRegisterGame = () => {
    Axios.post("http://localhost:3001/register", {
      name: values.name,
      cost: values.cost,
      category: values.category,
    }).then(() => {
      Axios.post("http://localhost:3001/search", {
        name: values.name,
        cost: values.cost,
        category: values.category,
    }).then((response) => {
      setListCard([
        ...listCard,
        {
          id: response.data[0].id,
          name: values.name,
          cost: values.cost,
          category: values.category,
        },
      ]);
      });
    });
  };

  useEffect(() => {
    Axios.get("http://localhost:3001/getCards").then((response) => {
      setListCard(response.data);
    });
  }, []);

  const handleaddValues = (value) => {
    setValues((prevValues) => ({
      ...prevValues,
      [value.target.name]: value.target.value,
    }));
  };



  return (
    
    <div className="app-container">
      <div className="corpo1">
        <h1>FoxFive</h1>
      </div>
      <div className="corpo2">
        <h1>Livraria virtual</h1>
      </div>
      <div className="corpo2">
        <h1>Sobre Nós</h1>
        <p>
A origem da livraria da FOXFIVE, com sua origem mais especificamente da capital do estado, Rio de Janeiro. Tudo começou com um pequeno Curso de Programação aonde foi criado por um grupo de amigos.<br></br>
A ideia era vender livros usados em bom estado de forma Virtual— assim como é a proposta da grande maioria das lojas. A sua localização era através da loja online, ponto tradicional na parte central de  RJ que abriga várias boutiques ecléticas e restaurantes.<br></br>
O nome original era “Livraria Lê”. A pequena livraria em questão foi aumentando até os dias de hoje.<br></br>
Atualmente, a rede tem atualmente 81 lojas parceiras distribuídas em diversos Estados do Brasil. <br></br>
Apesar dos pesares, a Livraria Leitura FOX Five  continua de pé,  o serviço disponibilizado pelo site oficial. E de acordo com a sua visão, o objetivo é continuar crescendo:<br></br>
“Nosso objetivo é ser a melhor loja de entretenimento e informação, nos consolidando como a grande referência do setor. Quanto mais crescermos, mais vamos disseminar essa informação, ajudando as pessoas a construir e viver em um mundo melhor e mais justo.”<br></br>
Atualmente, a Livraria  Leitura Fox Five se dedica a oferecer um espaço multimídia, no qual a busca pelo produto é apenas o início de uma jornada enriquecedora.<br></br>
E você, já comprou algum título na Livraria Leitura FOX Five? Não deixe de comentar qual é e também como foi a sua experiência dentro da loja.<br></br>
        </p>
      </div>
      <div className="corpo3">
       <h1>Propósito</h1>
      <p>Trazer a leitura para todas classes sociais com acessibilidade e qualidade.</p>

      </div>


    <div className="register-container">
  <h1 className="register-tittle">Cadastro de Livros</h1>
        <input type="text" name="name" placeholder="nome do livro" className="register-input" onChange={handleaddValues} />
        <input type="text" name="cost" placeholder="valor do livro" className="register-input" onChange={handleaddValues} />
        <input type="text" name="category" placeholder="Categoria do livro" className="register-input" onChange={handleaddValues} />
        <button onClick={handleRegisterGame} className="register-button">Cadastrar</button>
</div>

      
      
      
      
      {listCard.map((val) => (
        <Card 
          listCard={listCard} 
          setListCard={setListCard}
          key={val.id}
          id={val.id}
          name={val.name}
          cost={val.cost}
          category={val.category}
        />
      ))}


     <div className="footer">
      Desenvolvido pela FoxFive
     </div>

    </div>
  );
}

export default App;
